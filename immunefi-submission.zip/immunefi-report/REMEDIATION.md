# Lombard Finance — Report #72762: Remediation

## Root Cause Summary

Two compounding bugs enable LBTC minting with zero BTC deposited:

**Bug 1 — Storage split between Mailbox and AssetRouter:**
`Mailbox.deliveredPayload[hash]` is set in Mailbox storage and persists across
handler failures by design — `Mailbox._handle()` uses try/catch to explicitly
isolate handler failures. When `AssetRouter.handlePayload()` reverts due to
Bascule blocking, Solidity unwinds the entire AssetRouter call frame including
any `usedPayloads[id] = true` written inside it. Result: `deliveredPayload=true`
in Mailbox, `usedPayloads=false` in AssetRouter — simultaneously.

**Bug 2 — Proof verification skipped on retry:**
`Mailbox._verifyPayload()` skips `consortium.checkProof()` when
`deliveredPayload[hash]` is already true. An attacker who triggers the storage
split can retry with an empty proof — Consortium check silently skipped, only
Bascule stands in the way.

**Bug 3 — Bascule can be fully disabled:**
`changeBascule(address(0))` removes the only remaining check on retry.

---

## Fix 1 — Mailbox: always verify proof (closes Bug 2)

**File:** `contracts/gmp/Mailbox.sol`

```solidity
// WRONG — current code
function _verifyPayload(..., bytes calldata proof) internal {
    if (!$.deliveredPayload[payloadHash]) {
        $.consortium.checkProof(payloadHash, proof); // checked ONCE only
        $.deliveredPayload[payloadHash] = true;
    }
    // silent skip on retry — no proof required
}

// CORRECT
function _verifyPayload(..., bytes calldata proof) internal {
    $.consortium.checkProof(payloadHash, proof); // always verify
    if ($.deliveredPayload[payloadHash]) revert Mailbox_AlreadyDelivered();
    $.deliveredPayload[payloadHash] = true;
}
```

**Effect:** Every `deliverAndHandle()` call — including retries — must supply
a valid Consortium proof. Removes the proof-bypass vector entirely.

---

## Fix 2 — AssetRouter + Mailbox: prevent storage split (closes Bug 1)

**File:** `contracts/gmp/Mailbox.sol` and `contracts/LBTC/AssetRouter.sol`

**Critical EVM note:** Moving `usedPayloads[id] = true` before `_confirmMint()`
does NOT prevent the storage split. If `_confirmMint()` reverts, Solidity
unwinds the entire call frame — including the flag write. The flag is NOT
persisted. The split exists because Mailbox storage and AssetRouter storage
are in separate contracts: a revert in AssetRouter cannot unwind Mailbox state.

The correct fix eliminates the state where both can be true simultaneously.
Two options:

**Option A — Remove try/catch in Mailbox (simplest):**

```solidity
// Mailbox._handle(): remove try/catch
// A handler revert now propagates upward and prevents deliveredPayload from being set.
function _handle(...) internal {
    // No try/catch — revert propagates, deliveredPayload never set on failure
    bytes memory result = IHandler(payload.msgRecipient).handlePayload(payload);
    emit MessageHandled(payloadHash, msg.sender, result);
    $.handledPayload[payloadHash] = true;
}
```

**Option B — Make Bascule non-reverting, gate usedPayloads on success:**

```solidity
// AssetRouter.handlePayload()
function handlePayload(...) external returns (bytes memory) {
    if ($.usedPayloads[payload.id]) revert AssetRouter_PayloadAlreadyUsed();
    bool basculeOk = _tryConfirmMint(...); // returns bool, never reverts
    if (!basculeOk) revert AssetRouter_BasculeRejected();
    $.usedPayloads[payload.id] = true; // only reached on full success
    lbtc.mint(...);
}
```

**Effect:** No intermediate state where `deliveredPayload=true` and
`usedPayloads=false` can coexist.

---

## Fix 3 — AssetRouter: reject address(0) as Bascule (hardening)

```solidity
function changeBascule(address newBascule) external onlyAdmin {
    require(newBascule != address(0), "AssetRouter: bascule cannot be zero");
    $.bascule = newBascule;
}
```

This is defense-in-depth, not a root cause fix. The storage split is
exploitable even with an active Bascule if Fix 1 and Fix 2 are not applied.

---

## Attack path after each fix

| Step | No fix | Fix 1 only | Fix 2 only | Fix 1 + Fix 2 |
|------|--------|-----------|-----------|--------------|
| Phase 1: deliver, Bascule blocks | split created | split created | split impossible | split impossible |
| Phase 3: retry with empty proof | proof skipped → mint | valid proof required → fail | split gone → fail | both vectors closed |

---

## Minimum viable fix

Apply Fix 1 to Mailbox. This requires a valid Consortium proof on every
attempt. Without a fresh valid proof the retry cannot proceed regardless of
Bascule state. The storage split remains structurally possible but is not
exploitable.

For a complete fix, apply both Fix 1 and Fix 2.
