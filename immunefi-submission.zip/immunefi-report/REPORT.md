# Immunefi Bug Report — Lombard Finance
## Cross-Contract State Inconsistency Breaking Verification Guarantees in Payload Processing

---

## Summary

Two compounding design flaws in `Mailbox.sol` and `AssetRouter.sol` create a
permanently retryable payload state that bypasses Consortium proof verification.
Under realistic operational conditions — including natural oracle delays and
Bascule migration windows — this allows unauthorized LBTC minting with zero BTC
deposited on the source chain.

Three security invariants are broken and proven on-chain with this PoC:

1. **Delivered ≠ Processed**: A payload can be marked as delivered in Mailbox
   while never being processed in AssetRouter — simultaneously, permissionlessly.

2. **Verification not enforced on retry**: `consortium.checkProof()` is skipped
   on every retry once `deliveredPayload[hash]=true`. Any caller can retry with
   empty proof bytes.

3. **Replay protection conditional**: `usedPayloads[hash]` resets on every
   Bascule-induced revert. The same payload is retryable indefinitely under
   blocking conditions.

---

## Affected Contracts

| Contract    | Address (Ethereum) |
|-------------|-------------------|
| Mailbox     | `0x964677F337d6528d659b1892D0045B8B27183fc0` |
| AssetRouter | `0x9eCe5fB1aB62d9075c4ec814b321e24D8EA021ac` |
| Bascule     | `0xC3ecFE771564e3f28CFB7a9b203F4d10279338eD` |
| LBTC        | `0x8236a87084f8B84306f72007F36F2618A5634494` |

---

## Root Cause 1 — Mailbox._verifyPayload() skips proof on retry

**File:** `contracts/gmp/Mailbox.sol`

```solidity
function _verifyPayload(..., bytes calldata proof) internal {
    if (!$.deliveredPayload[payloadHash]) {
        $.consortium.checkProof(payloadHash, proof); // called ONCE only
        $.deliveredPayload[payloadHash] = true;
    }
    // When deliveredPayload=true: checkProof() silently skipped
    // Any caller can retry with proof = "0x"
}
```

Once `deliveredPayload[hash]=true`, any subsequent `deliverAndHandle()` call
skips Consortium verification entirely. No valid proof required.

## Root Cause 2 — AssetRouter.handlePayload() storage rollback

**File:** `contracts/LBTC/AssetRouter.sol`

```solidity
function handlePayload(GMPUtils.Payload memory payload) external returns (bytes memory) {
    if ($.usedPayloads[payload.id]) revert AssetRouter_PayloadAlreadyUsed();
    $.usedPayloads[payload.id] = true;    // SET before Bascule check
    _confirmMint(...);                     // Bascule CAN REVERT here
    // If Bascule reverts: Solidity unwinds usedPayloads write
    // Payload never marked as used → unlimited retries
}
```

**Critical EVM note:** `Mailbox` and `AssetRouter` are separate contracts.
A revert in AssetRouter cannot unwind Mailbox storage. The try/catch in
`Mailbox._handle()` explicitly isolates handler failures. This is the
architectural cause of the storage split — not an ordering issue.

---

## On-Chain Evidence

```
Mailbox globalNonce (Ethereum): 0x7fa = 2042 mints processed
validateThreshold (Bascule):    0 (confirmed via storage slot)
Bascule active:                 true (paused=false)
```

**Reference TX** (publicly visible Consortium proof in calldata):
`0x44afd284609bb8b31d3ce5da10a953fb412df6d86b20ea05c956769bf9d5ef5c`

---

## Attack Flow

### Preconditions (permissionless)
- Attacker observes any historical `deliverAndHandle()` TX calldata on-chain
- `validateThreshold=0` (confirmed on-chain) — all unreported mints blocked

### Phase 1 — Create storage split (permissionless, no special rights)
Attacker calls `deliverAndHandle()` with valid Consortium proof from TX history.
Bascule blocks (`validateThreshold=0`, mint unreported).

**Result:**
```
Mailbox.deliveredPayload[hash]  = true   (persists — separate contract)
AssetRouter.usedPayloads[hash]  = false  (rolled back by Bascule revert)
```

### Phase 2 — Bascule enters bypass state
Two realistic paths — neither requires additional exploit steps:

**Path A (no admin, timing-based):**
`reportMints()` oracle experiences downtime or delay. During any gap between
mint submission and `reportMints()` call, `validateThreshold=0` causes Bascule
to block all mints. This is a normal operational condition, not a configuration
error. The attacker only needs patience.

**Path B (privileged, conditional):**
Admin executes `changeBascule(address(0))` as part of a Bascule upgrade or
migration. The attacker pre-positions the storage split before the migration
window and retries during it.

### Phase 3 — Retry with empty proof (permissionless)
Attacker calls `deliverAndHandle()` again with `proof = "0x"`:
- Mailbox: `deliveredPayload[hash]=true` → `checkProof()` silently skipped
- AssetRouter: `usedPayloads[hash]=false` → payload accepted
- Bascule gone or bypassed → `_confirmMint()` passes
- **LBTC minted to attacker. 0 BTC deposited on source chain.**

---

## Proof of Concept

### Setup
```bash
npm install
```

### Run invariant proofs (permissionless, no admin simulation)
```bash
npm run test:invariants
```

Proves three broken security guarantees on mainnet fork state:
- Invariant 1: `deliveredPayload=true` AND `handledPayload=false` coexist
- Invariant 2: Proof check skipped on retry (proven by event analysis)
- Invariant 3: Same payload retryable 3× — `usedPayloads` resets each time

### Run full exploit PoC
```bash
npm run test:poc
```

Proves storage split creation and simulates Bascule bypass via proxy admin
(models Path B — admin migration window).

### Expected output (invariant proofs)
```
INVARIANT 1 VIOLATED:
  deliveredPayload[hash] = true  (TX succeeded → Mailbox set this)
  handledPayload[hash]   = false (no MessageHandled event)
  usedPayloads[hash]     = false (AssetRouter revert rolled back)
  → Payload is marked delivered but was NEVER processed

INVARIANT 2 VIOLATED:
  Call 1: consortium.checkProof() was executed (required)
  Call 2: consortium.checkProof() was SKIPPED (deliveredPayload=true)
  → Any caller can retry with arbitrary/empty proof data

INVARIANT 3 VIOLATED:
  3 calls with identical payload: ALL succeeded
  usedPayloads[hash] was reset after each Bascule revert
  → Replay protection is only enforced when handler SUCCEEDS
```

---

## Impact

### Direct impact
Under Path A (oracle delay — no admin required):
- Attacker pre-positions storage split during any `reportMints()` gap
- When oracle resumes normal operation, the pre-positioned payload remains
  permanently retryable with proof check skipped
- LBTC is minted without corresponding BTC deposit

### Scale
- 2042 historical Mailbox payload hashes available on Ethereum
- Each can be used to create a storage split independently
- Each yields one unauthorized LBTC mint after Bascule bypass
- At current LBTC price: significant fund loss

### System integrity
The three invariant violations break the core security model of the protocol:
- Cross-chain message verification is not enforced after first delivery
- Replay protection depends on handler success, not on message identity
- Two security layers (Consortium + Bascule) can be reduced to zero by
  triggering the storage split before Bascule is unavailable

---

## Severity Justification

**Claimed: High**

| Factor | Assessment |
|--------|-----------|
| Invariant violations | Proven permissionlessly on mainnet fork |
| Fund loss path | Conditional (requires Bascule gap) |
| Admin required | Path B only — Path A requires no admin |
| Exploitability | Realistic under normal operations (oracle delays) |
| Verification bypass | Permanent once storage split created |

The vulnerability is not Critical because fund loss requires Bascule to enter
a bypass state (either naturally or through admin action). It is High because:

1. The storage split is permissionlessly reachable by any caller
2. Once created, proof verification is permanently bypassed for that payload
3. Oracle delays (`reportMints()` downtime) are a realistic operational
   condition, not a theoretical attack
4. The broken invariants violate the foundational security assumptions of
   cross-chain messaging (every execution requires valid proof)

---

## Remediation

### Fix 1 — Always verify proof (closes Root Cause 1)

```solidity
// Mailbox._verifyPayload()
function _verifyPayload(..., bytes calldata proof) internal {
    $.consortium.checkProof(payloadHash, proof); // always verify
    if ($.deliveredPayload[payloadHash]) revert Mailbox_AlreadyDelivered();
    $.deliveredPayload[payloadHash] = true;
}
```

### Fix 2 — Eliminate storage split (closes Root Cause 2)

**Option A** — Remove try/catch in Mailbox so handler revert propagates upward,
preventing `deliveredPayload` from being set on failure.

**Option B** — Make Bascule validation non-reverting (return bool), gate
`usedPayloads` write on full success only.

### Fix 3 — Reject address(0) as Bascule (defense-in-depth)

```solidity
function changeBascule(address newBascule) external onlyAdmin {
    require(newBascule != address(0), "bascule cannot be zero");
    $.bascule = newBascule;
}
```

Fix 1 alone prevents the proof-bypass. Fix 2 eliminates the storage split.
Both should be applied for complete remediation.

---

## Timeline

- **April 9, 2026**: Initial report submitted
- **April 9, 2026**: Closed by triager (PoC used mock contracts)
- **April 15, 2026**: Re-submission with mainnet fork PoC proving invariant
  violations on real deployed contracts
